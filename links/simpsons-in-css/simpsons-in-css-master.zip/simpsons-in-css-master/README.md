## Simpsons in CSS

Simpsons characters in pure CSS

[View the project page](http://pattle.github.io/simpsons-in-css "Simpsons in CSS")